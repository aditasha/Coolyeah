package com.papb.coolyeah

import android.net.Uri

class Kelas(nama: Any?, desc: Any?, pengajar: Any?, image: Any?, akronim: Any?) {
    var _nama: Any?
    var _desc: Any?
    var _pengajar: Any?
    var _image: Any?
    var _akronim: Any?

    init {
        _nama = nama
        _desc = desc
        _pengajar = pengajar
        _image = image
        _akronim = akronim
    }
}