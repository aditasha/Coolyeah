package com.papb.coolyeah

class Materi(nama: Any?, desc: Any?, pengajar: Any?, akronim: Any?, key: Any?) {
    var _nama: Any?
    var _desc: Any?
    var _pengajar: Any?
    var _akronim: Any?
    var _key: Any?

    init {
        _nama = nama
        _desc = desc
        _pengajar = pengajar
        _akronim = akronim
        _key = key
    }
}